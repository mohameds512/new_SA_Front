<template>
<div>
  <h1></h1>
      <Engine_Types></Engine_Types>
</div>
</template>

<script>
    // import Airports from "@/views/airport/components/airports";
    import Engine_Types from "../engine_type/components/engine_types.vue"

    export default {
        name: "index",
        components: {Engine_Types}
    }
</script>

<style scoped>

</style>