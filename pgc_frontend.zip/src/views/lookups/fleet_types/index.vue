<template>
<div>
  <h1></h1>
      <Fleet_Type></Fleet_Type>
</div>
</template>

<script>
    // import Airports from "@/views/airport/components/airports";
    import Fleet_Type from "../fleet_types/components/fleet_type.vue"

    export default {
        name: "index",
        components: {Fleet_Type}
    }
</script>

<style scoped>

</style>