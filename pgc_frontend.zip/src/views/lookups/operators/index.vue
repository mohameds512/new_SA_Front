<template>
<div>
  <h1></h1>
      <Operators></Operators>
</div>
</template>

<script>
    // import Airports from "@/views/airport/components/airports";

    import Operators from "../operators/components/operators.vue"
    export default {
        name: "index",
        components: {Operators}
    }
</script>

<style scoped>

</style>