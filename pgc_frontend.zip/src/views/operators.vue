<template>
    <section id="dashboard-ecommerce">
    
        <div>
            <h2>User Dashboard</h2>
        </div>
    </section>
</template>

<script>
    import {BRow, BCol} from 'bootstrap-vue'
  

    export default {
    
    }
</script>

<style lang="scss">
    @import '@core/scss/vue/pages/dashboard-ecommerce.scss';

</style>
