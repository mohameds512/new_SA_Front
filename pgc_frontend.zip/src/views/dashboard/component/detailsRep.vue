<template>
    <div class="main_pdf_details_wrapper" style="direction: rtl;">
      <!-- Start Section Part One  -->
      <section class="section_part_one">
        <div class="num_one">
          <!-- <img src="@/assets/images/Picture1.png" alt="" /> -->
        </div>
        <div class="num_two">
          <div class="wrap_a with_center_text">
            المخطط التفصيلي للعقار رقم ( ) بـــمركز ( ) بمحافظة ( ) بمنطقة ( )
          </div>
          <div class="two one">two</div>
          <div class="three one">three</div>
          <div class="four one">four</div>
          <div class="five one">five</div>
        </div>
        <div class="num_three">
          <div class="one">
            <span class="name">إسم المالك</span>
            <span></span>
          </div>
          <div class="two one">
            <span class="name">رقم الهوية الوطنية</span>
            <span></span>
          </div>
          <div class="three one">
            <span class="name">اسم المشروع</span>
            <span></span>
          </div>
          <div class="four one">
            <span class="name">استعمال العقار</span>
            <span></span>
          </div>
          <div class="five one">
            <span class="name">تصنيف العقار</span>
            <span></span>
          </div>
        </div>
      </section>
      <!-- End Section Part One  -->
  
      <!-- Start Section Part Two  -->
      <section class="main_part_two_wrapper">
        <!-- Start Section Part Two --- [ Part one ]  -->
        <section class="section_part_two">
          <!-- Start Wrapper A  -->
          <div class="our_part_wrapper">
            <!-- Start Part One Container -->
            <div class="part_one_container">
              <div class="main_container_title">
                <span>مساحة كامل العقار م2</span>
              </div>
              <div class="div_container_a">
                <div class="content_wrapper_a">
                  <div class="title">
                    <span>ارض</span>
                  </div>
                  <div class="wrapper_data">
                    <div class="one">
                      <span class="names">مبينة</span>
                      <span></span>
                    </div>
                    <div class="one two">
                      <span class="names">غير مبينة</span>
                      <span></span>
                    </div>
                    <div class="one two">
                      <span class="names">المجموع</span>
                      <span></span>
                    </div>
                  </div>
                </div>
              </div>
              <div class="div_container_b">
                <div class="content_wrapper_a">
                  <div class="title">
                    <span>بناء</span>
                  </div>
                  <div class="wrapper_data">
                    <div class="one">
                      <span class="names">تحت الارضي</span>
                      <span></span>
                    </div>
                    <div class="one two">
                      <span class="names">الارضي</span>
                      <span></span>
                    </div>
                    <div class="one two">
                      <span class="names">اول</span>
                      <span></span>
                    </div>
                    <div class="one two">
                      <span class="names">ثاني</span>
                      <span></span>
                    </div>
                    <div class="one two">
                      <span class="names">ثالث</span>
                      <span></span>
                    </div>
                    <div class="one two">
                      <span class="names">رابع</span>
                      <span></span>
                    </div>
                    <div class="one two">
                      <span class="names">خامس</span>
                      <span></span>
                    </div>
                    <div class="one two">
                      <span class="names">المجموع</span>
                      <span></span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- End Part One Container -->
  
            <!-- Start Part Two Container -->
            <div class="part_two_container">
              <div class="div_container_a">
                <div
                  class="a_one d-flex justify-content-center align-items-center"
                >
                  <span>المساحات المنزوعه</span>
                </div>
                <div class="a_two"></div>
              </div>
              <div class="div_container_a div_container_b">
                <div
                  class="a_one d-flex justify-content-center align-items-center"
                >
                  <span>ملاحظات</span>
                </div>
                <div class="a_two"></div>
              </div>
            </div>
            <!-- End Part Two Container -->
          </div>
          <!-- End Wrapper A  -->
  
          <!-- Start Wrapper B  -->
          <div class="our_part_wrapper_b">
            <div class="part_b_one with_border_left">
              <div class="title with_border_bottom">
                <span>الحدود والأطوال بموجب وثيقة الملكية</span>
              </div>
              <div class="for_content">
                <div class="title_parts with_border_bottom">
                  <span class="one with_border_left with_center_text"
                    >الإتجاه</span
                  >
                  <span class="one two with_border_left with_center_text"
                    >الحدود</span
                  >
                  <span class="one three with_center_text">الطول (م)</span>
                </div>
                <!-- Start Directions  -->
                <div class="title_parts with_border_bottom">
                  <span class="one with_border_left with_center_text"
                    >شمالاً</span
                  >
                  <span class="one two with_border_left with_center_text"></span>
                  <span class="one three with_center_text"></span>
                </div>
                <div class="title_parts with_border_bottom">
                  <span class="one with_border_left with_center_text"
                    >جنوباً</span
                  >
                  <span class="one two with_border_left with_center_text"></span>
                  <span class="one three with_center_text"></span>
                </div>
                <div class="title_parts with_border_bottom">
                  <span class="one with_border_left with_center_text">شرقاً</span>
                  <span class="one two with_border_left with_center_text"></span>
                  <span class="one three with_center_text"></span>
                </div>
                <div class="title_parts with_border_bottom">
                  <span class="one with_border_left with_center_text">غرباً</span>
                  <span class="one two with_border_left with_center_text"></span>
                  <span class="one three with_center_text"></span>
                </div>
                <div class="title_parts with_border_bottom">
                  <span class="one with_border_left with_center_text"
                    >المساحة م2</span
                  >
                  <span class="one two with_border_left with_center_text"></span>
                  <span class="one three with_center_text"></span>
                </div>
                <!-- End Directions  -->
              </div>
            </div>
            <div class="part_b_one">
              <div class="title with_border_bottom">
                <span>الحدود والأطوال بموجب أعمال الحصر الميداني</span>
              </div>
              <div class="for_content">
                <div class="title_parts with_border_bottom">
                  <span class="one with_border_left with_center_text"
                    >الإتجاه</span
                  >
                  <span class="one two with_border_left with_center_text"
                    >الحدود</span
                  >
                  <span class="one three with_center_text">الطول (م)</span>
                </div>
                <!-- Start Directions  -->
                <div class="title_parts with_border_bottom">
                  <span class="one with_border_left with_center_text"
                    >شمالاً</span
                  >
                  <span class="one two with_border_left with_center_text"></span>
                  <span class="one three with_center_text"></span>
                </div>
                <div class="title_parts with_border_bottom">
                  <span class="one with_border_left with_center_text"
                    >جنوباً</span
                  >
                  <span class="one two with_border_left with_center_text"></span>
                  <span class="one three with_center_text"></span>
                </div>
                <div class="title_parts with_border_bottom">
                  <span class="one with_border_left with_center_text">شرقاً</span>
                  <span class="one two with_border_left with_center_text"></span>
                  <span class="one three with_center_text"></span>
                </div>
                <div class="title_parts with_border_bottom">
                  <span class="one with_border_left with_center_text">غرباً</span>
                  <span class="one two with_border_left with_center_text"></span>
                  <span class="one three with_center_text"></span>
                </div>
                <div class="title_parts with_border_bottom">
                  <span class="one with_border_left with_center_text"
                    >المساحة م2</span
                  >
                  <span class="one two with_border_left with_center_text"></span>
                  <span class="one three with_center_text"></span>
                </div>
                <!-- Endv Directions  -->
              </div>
            </div>
          </div>
          <!-- End Wrapper B  -->
  
          <!-- Start Wrapper C  -->
          <div class="our_part_wrapper_c with_border_left with_border_bottom">
            <div class="title with_center_text with_border_bottom">
              <span>بيانات الأرض والمشتملات المنزوعه</span>
            </div>
            <div class="main_content">
              <!-- Wrapper C Part One  -->
              <div class="content_one with_border_left">
                <div class="title_parts with_border_bottom">
                  <span class="one with_border_left with_center_text">النوع</span>
                  <span class="one two with_border_left with_center_text">
                    المنزوع من العقار
                  </span>
                  <span class="one three with_center_text">الوحده</span>
                </div>
                <!-- Start Directions  -->
                <div class="title_parts with_border_bottom">
                  <span class="one with_border_left with_center_text">ارض</span>
                  <span class="one two with_border_left with_center_text"></span>
                  <span class="one three with_center_text">م2</span>
                </div>
                <div class="title_parts with_border_bottom">
                  <span class="one with_border_left with_center_text">بناء</span>
                  <span class="one two with_border_left with_center_text"></span>
                  <span class="one three with_center_text">م2</span>
                </div>
                <div class="title_parts with_border_bottom">
                  <span class="one with_border_left with_center_text">اسوار</span>
                  <span class="one two with_border_left with_center_text"></span>
                  <span class="one three with_center_text">م/ط</span>
                </div>
                <div class="title_parts with_border_bottom">
                  <span class="one with_border_left with_center_text"
                    >ابار مياه</span
                  >
                  <span class="one two with_border_left with_center_text"></span>
                  <span class="one three with_center_text">عدد</span>
                </div>
                <div class="title_parts with_border_bottom">
                  <span class="one with_border_left with_center_text"
                    >خزانات مياه</span
                  >
                  <span class="one two with_border_left with_center_text"></span>
                  <span class="one three with_center_text">عدد</span>
                </div>
                <div class="title_parts with_border_bottom">
                  <span class="one with_border_left with_center_text">بياره</span>
                  <span class="one two with_border_left with_center_text"></span>
                  <span class="one three with_center_text">عدد</span>
                </div>
                <div class="title_parts with_border_bottom">
                  <span class="one with_border_left with_center_text">بركه</span>
                  <span class="one two with_border_left with_center_text"></span>
                  <span class="one three with_center_text">عدد</span>
                </div>
                <div class="title_parts">
                  <span class="one with_border_left with_center_text">أشجار</span>
                  <span class="one two with_border_left with_center_text"></span>
                  <span class="one three with_center_text">إجمالي الاعداد</span>
                </div>
                <!-- End Directions  -->
              </div>
              <!-- Wrapper C Part Two  -->
              <div class="content_two">
                <div class="titles with_center_text with_border_bottom">
                  <div class="one_a with_center_text with_border_left">
                    <span>الوصف</span>
                  </div>
                  <div class="one_a with_center_text">
                    <span>القيمه "ريال سعودي"</span>
                  </div>
                </div>
                <div class="content_parts with_border_bottom">
                  <span class="one with_border_left with_center_text"
                    >إجمالي التعويض</span
                  >
                  <span class="one three with_center_text"></span>
                </div>
                <div class="content_parts with_border_bottom">
                  <span class="one with_border_left with_center_text"
                    >إجمالي التعويض بدون أرض</span
                  >
                  <span class="one three with_center_text"></span>
                </div>
                <div class="content_parts with_border_bottom">
                  <span class="one with_border_left with_center_text"
                    >إعادة تحسين المستوى المعيشي</span
                  >
                  <span class="one three with_center_text"></span>
                </div>
                <div class="content_parts">
                  <span class="one with_border_left with_center_text"
                    >بدل انتقال</span
                  >
                  <span class="one three with_center_text"></span>
                </div>
              </div>
            </div>
          </div>
          <!-- End Wrapper C  -->
  
          <!-- Start Wrapper D  -->
          <div class="our_part_wrapper_d with_border_left with_center_text">
            <div class="part_d_one with_border_left">
              <div class="content_cont_c with_border_bottom">
                <span class="name with_border_left with_center_text"
                  >الوظيفه</span
                >
                <span></span>
              </div>
              <div class="content_cont_c with_border_bottom">
                <span class="name with_border_left with_center_text">الإسم</span>
                <span></span>
              </div>
              <div class="content_cont_c with_border_bottom">
                <span class="name with_border_left with_center_text"
                  >التوقيع</span
                >
                <span></span>
              </div>
              <div class="content_cont_c">
                <span class="name with_border_left with_center_text"
                  >التاريخ</span
                >
                <span class="with_center_text flex-grow-1"> / / 14هـ</span>
              </div>
            </div>
            <div class="part_d_one">
              <div class="content_cont_c with_border_bottom">
                <span class="name with_border_left with_center_text"
                  >الوظيفه</span
                >
                <span></span>
              </div>
              <div class="content_cont_c with_border_bottom">
                <span class="name with_border_left with_center_text">الإسم</span>
                <span></span>
              </div>
              <div class="content_cont_c with_border_bottom">
                <span class="name with_border_left with_center_text"
                  >التوقيع</span
                >
                <span></span>
              </div>
              <div class="content_cont_c">
                <span class="name with_border_left with_center_text"
                  >التاريخ</span
                >
                <span class="with_center_text flex-grow-1"> / / 14هـ</span>
              </div>
            </div>
          </div>
          <!-- End Wrapper D -->
        </section>
        <!-- End Section Part Two ---  [ Part one ] -->
        <!-- Start Section Part Two ---  [ Part Two ] -->
        <section class="section_part_two_wrapper_two">
          <div class="main_part_two_section">
            <div class="section_title with_center_text with_border_bottom">
              <span>موقع العقار</span>
            </div>
            <div class="wrapper_numbers">
              <div class="aside_one with_border_left">
                <div class="one_a with_border_bottom">
                  <span class="a_a with_border_left">رمز الشركة</span>
                  <span class="a_a_b with_border_left">رمز المشروع</span>
                  <span class="a_a">المنطقة</span>
                </div>
                <div class="all_inputs">
                  <div class="inputs_one">
                    <span>hello</span>
                    <span>hello</span>
                  </div>
                  <div class="inputs_one">
                    <span>hello</span>
                    <span>hello</span>
                  </div>
                  <div class="inputs_one">
                    <span>hello</span>
                    <span>hello</span>
                  </div>
                </div>
              </div>
              <div class="aside_one">
                <span>jhfskjdf</span>
              </div>
            </div>
          </div>
        </section>
        <!-- End Section Part Two ---  [ Part Two ] -->
      </section>
      <!-- End Section Part Two  -->
    </div>
  </template>
  
  <script>
  export default {};
  </script>
  
  <style lang="scss">
  $border-color: #ccc;
  $column-height: 26px;
  $min-part-height: 130px;
  $min-name-width: 120px;
  .with_border_left {
    border-left: 1px solid $border-color;
  }
  .with_border_bottom {
    border-bottom: 1px solid $border-color;
  }
  .with_center_text {
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .main_pdf_details_wrapper {
    background-color: #fff;
    width: 1600px;
    border: 1px solid $border-color;
    // Start Section Part One
    .section_part_one {
      border-bottom: 1px solid $border-color;
      display: flex;
      direction: rtl;
      text-align: right;
      .num_one {
        width: 30%;
        min-height: $min-part-height;
        display: flex;
        justify-content: center;
      }
      .num_two {
        min-height: $min-part-height;
        width: 40%;
        border-right: 1px solid $border-color;
        border-left: 1px solid $border-color;
        .wrap_a {
          border-bottom: 1px solid $border-color;
          height: $column-height;
        }
        .one {
          height: $min-part-height / 5;
        }
        .two {
          border-top: 1px solid $border-color;
        }
        .three {
          border-top: 1px solid $border-color;
        }
        .four {
          border-top: 1px solid $border-color;
        }
        .five {
          border-top: 1px solid $border-color;
        }
      }
      .num_three {
        width: 30%;
        min-height: $min-part-height;
        .one {
          height: $min-part-height / 5;
          display: flex;
          gap: 8px;
          .name {
            min-width: $min-name-width;
            border-left: 1px solid $border-color;
            display: flex;
            justify-content: center;
            align-items: center;
          }
        }
        .two {
          border-top: 1px solid $border-color;
        }
        .three {
          border-top: 1px solid $border-color;
        }
        .four {
          border-top: 1px solid $border-color;
        }
        .five {
          border-top: 1px solid $border-color;
        }
      }
    }
    // End Section Part One
  
    // Start Section Part Two
    .main_part_two_wrapper {
      display: flex;
      direction: rtl;
      .section_part_two {
        width: 60%;
        // Start Wrapper A
        .our_part_wrapper {
          display: flex;
          direction: rtl;
          text-align: right;
          // Start Part One Style
          .part_one_container {
            width: 50%;
            border-left: 1px solid $border-color;
            display: flex;
            direction: rtl;
            text-align: right;
            flex-wrap: wrap;
            .main_container_title {
              width: 100%;
              border-bottom: 1px solid $border-color;
              display: flex;
              justify-content: center;
              align-items: center;
              height: $column-height;
            }
            .div_container_a {
              width: 50%;
              border-left: 1px solid $border-color;
              .content_wrapper_a {
                .title {
                  border-bottom: 1px solid $border-color;
                  height: $column-height;
                  display: flex;
                  justify-content: center;
                  align-items: center;
                }
                .wrapper_data {
                  .one {
                    display: flex;
                    gap: 8px;
                    .names {
                      height: $column-height * 2;
                      min-width: $min-name-width;
                      border-left: 1px solid $border-color;
                      display: flex;
                      justify-content: center;
                      align-items: center;
                    }
                    &.two {
                      border-top: 1px solid $border-color;
                      .names {
                        height: $column-height * 3;
                      }
                    }
                  }
                }
              }
            }
            .div_container_b {
              width: 50%;
              .content_wrapper_a {
                .title {
                  border-bottom: 1px solid $border-color;
                  height: $column-height;
                  display: flex;
                  justify-content: center;
                  align-items: center;
                }
                .wrapper_data {
                  .one {
                    display: flex;
                    gap: 8px;
                    height: $column-height;
                    &.two {
                      border-top: 1px solid $border-color;
                    }
                    .names {
                      min-width: $min-name-width;
                      border-left: 1px solid $border-color;
                      display: flex;
                      justify-content: center;
                      align-items: center;
                    }
                  }
                }
              }
            }
          }
          // End Part One Style
  
          // Start Part two Style
          .part_two_container {
            width: 50%;
            display: flex;
            direction: rtl;
            text-align: right;
            .div_container_a {
              width: 50%;
              border-left: 1px solid $border-color;
              .a_one {
                border-bottom: 1px solid $border-color;
                height: $column-height;
              }
            }
            .div_container_b {
              width: 50%;
            }
          }
          // End Part two Style
        }
        // End Wrapper A
        // Start Wrapper B
        .our_part_wrapper_b {
          border-top: 1px solid $border-color;
          border-left: 1px solid $border-color;
          direction: rtl;
          text-align: right;
          display: flex;
          .part_b_one {
            width: 50%;
            .title {
              display: flex;
              justify-content: center;
              align-items: center;
              height: $column-height;
            }
            .for_content {
              .title_parts {
                display: flex;
                height: $column-height;
                .one {
                  width: $min-name-width;
                }
                .two {
                  width: $min-name-width * 2 + 30px;
                }
                .three {
                  width: $min-name-width - 30px;
                }
              }
            }
          }
        }
        // End Wrapper B
        // Start Wrapper C
        .our_part_wrapper_c {
          .title {
            height: $column-height;
          }
          .main_content {
            display: flex;
            .content_one {
              width: 50%;
              .title_parts {
                display: flex;
                height: $column-height;
                .one {
                  width: $min-name-width;
                }
                .two {
                  width: $min-name-width * 2 + 30px;
                }
                .three {
                  width: $min-name-width - 30px;
                }
              }
            }
            .content_two {
              width: 50%;
              .titles {
                .one_a {
                  width: 50%;
                  height: $column-height;
                }
              }
              .content_parts {
                display: flex;
                .one {
                  width: 50%;
                  height: $column-height * 2;
                }
              }
            }
          }
        }
        // End Wrapper C
        .our_part_wrapper_d {
          direction: rtl;
          text-align: right;
          .part_d_one {
            width: 50%;
            .content_cont_c {
              display: flex;
              height: $column-height * 2;
              .name {
                width: $min-name-width;
              }
            }
          }
        }
      }
      .section_part_two_wrapper_two {
        width: 40%;
        .main_part_two_section {
          .section_title {
            height: $column-height;
          }
          .wrapper_numbers {
            display: flex;
            direction: rtl;
            text-align: center;
            .aside_one {
              width: 50%;
              .one_a {
                display: flex;
                .a_a {
                  width: 30%;
                  display: block;
                }
                .a_a_b {
                  width: 40%;
                }
              }
              .all_inputs {
                display: flex;
              }
            }
          }
        }
      }
    }
    // End Section Part Two
  }
  </style>
  