export default [
    // {
    //   path: '/airports',
    //   name: 'airports',
    //   // component: () => import('@/views/airport/index'),
    //   meta: {
      
    //     breadcrumb: [
    //       { to: '/airports', text: 'Airports' },
    //       // { text: 'add_airports', active: true }
    //   ],
    //   },
    // },
    // {
    //   path: '/airports/add',
    //   name: 'airports-add',

    //   // component: () => import('@/views/airport/edit'),
    //   meta: {
    //       pageTitle: 'Add Airport',
    //       breadcrumb: [
    //           { to: '/airports', text: 'Airports' },
    //           { text: 'Add airport', active: true }
    //       ],
    //   },
    // },
    // {
    //   path: '/airports/edit/:id',
    //   name: 'airports-edit',

    //   // component: () => import('@/views/airport/edit'),
    //   meta: {
    //       pageTitle: 'Add Airport',
    //       breadcrumb: [
    //           { to: '/airports', text: 'Airports' },
    //           { text: 'Edit Airports', active: true }
    //       ],
    //   },
    // },
  ]
  