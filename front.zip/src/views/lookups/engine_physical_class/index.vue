<template>
    <div>

          <Engine_Physical_class></Engine_Physical_class>
    </div>
    </template>
    
    <script>
        // import Airports from "@/views/airport/components/airports";
        import Engine_Physical_class from "../engine_physical_class/components/engine_physical_class.vue"
    
        export default {
            name: "index",
            components: {Engine_Physical_class}
        }
    </script>
    
    <style scoped>
    
    </style>