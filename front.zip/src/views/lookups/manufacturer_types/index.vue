<template>
    <div>

          <Manufacturer_Types></Manufacturer_Types>
    </div>
    </template>
    
    <script>
        // import Airports from "@/views/airport/components/airports";
        import Manufacturer_Types from "../manufacturer_types/components/manufacturer_types.vue"
    
        export default {
            name: "index",
            components: {Manufacturer_Types}
        }
    </script>
    
    <style scoped>
    
    </style>