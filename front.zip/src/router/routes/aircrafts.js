export default [
//     {
//       path: '/aircrafts',
//       name: 'aircrafts',
//       component: () => import('@/views/aircraft/index'),
//       meta: {
      
//         breadcrumb: [
//           { to: '/aircrafts', text: 'Aircrafts' },
//           // { text: 'add_aircrafts', active: true }
//       ],
//       },
//     },

//     {
//       path: '/aircrafts/add',
//       name: 'aircrafts-add',
 
//       component: () => import('@/views/aircraft/edit'),
//       meta: {
//           pageTitle: 'Add Aircraft',
//           breadcrumb: [
//               { to: '/aircrafts', text: 'Aircrafts' },
//               { text: 'Add Aircrafts', active: true }
//           ],
//       },
//   },

//   {
//     path: '/aircrafts/edit/:id',
//     name: 'aircrafts-edit',
   
//       component: () => import('@/views/aircraft/edit'),
  
//     meta: {
//         pageTitle: 'Edit Aircraft',
//         breadcrumb: [
//             { to: '/aircrafts', text: 'Aircrafts' },
//             { text: 'Edit Aircraft', active: true }
//         ],
//     },
// },
  ]
  