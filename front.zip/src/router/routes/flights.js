export default [
//     {
//       path: '/flights',
//       name: 'flights',
//       component: () => import('@/views/flights/index'),
//       meta: {
      
//         breadcrumb: [
//           { to: '/flights', text: 'Flights' },
//           // { text: 'add_flights', active: true }
//       ],
//       },
//     },
//     {
//       path: '/flights-operations',
//       name: 'flights-operations',
//       component: () => import('@/views/flights/operations'),
//       meta: {
      
//         breadcrumb: [
//           { to: '/flights-operations', text: 'Flights Operations' },
//           // { text: 'add_flights', active: true }
//       ],
//       },
//     },
//     {
//       path: '/flights/edit/operation/:id',
//       name: 'flights-edit-operation',
     
//         component: () => import('@/views/flights/operation_edit'),
    
//       meta: {
//           pageTitle: 'Edit Flight Operation',
//           breadcrumb: [
//               { to: '/flights-operations', text: 'Flights Operations' },
//               { text: 'Edit Flights Operations', active: true }
//           ],
//       },
//     },
//     {
//       path: '/flights/add',
//       name: 'flights-add',
 
//       component: () => import('@/views/flights/edit'),
//       meta: {
//           pageTitle: 'Add Flights',
//           breadcrumb: [
//               { to: '/flights', text: 'Flights' },
//               { text: 'Add Flights', active: true }
//           ],
//       },
//   },
//   {
//     path: '/flights/edit/:id',
//     name: 'flights-edit',

//     component: () => import('@/views/flights/edit'),
//     meta: {
//         pageTitle: 'Edit Flights',
//         breadcrumb: [
//             { to: '/flights', text: 'Flights' },
//             { text: 'Edit Flights', active: true }
//         ],
//     },
// },
]