import pages from './pages'

export default [...pages ]
